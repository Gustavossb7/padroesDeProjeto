public class App {
    public static void main(String[] args) {
        Consultas consultas = new Consultas();
        System.out.println(consultas.diaQueMaisChoveuNoAno(1980));
    }
}
